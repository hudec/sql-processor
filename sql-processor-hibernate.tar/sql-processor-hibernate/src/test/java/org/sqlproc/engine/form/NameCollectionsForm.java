package org.sqlproc.engine.form;

import java.util.List;

public class NameCollectionsForm {
    private List<String> firstList;
    private List<String> lastList;

    public List<String> getFirstList() {
        return firstList;
    }

    public void setFirstList(List<String> firstList) {
        this.firstList = firstList;
    }

    public List<String> getLastList() {
        return lastList;
    }

    public void setLastList(List<String> lastList) {
        this.lastList = lastList;
    }
}

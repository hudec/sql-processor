package org.sqlproc.engine.form;

public class FormSimpleFunction {
    private java.sql.Timestamp time;
    private java.sql.Timestamp time2;

    public java.sql.Timestamp getTime() {
        return time;
    }

    public void setTime(java.sql.Timestamp time) {
        this.time = time;
    }

    public java.sql.Timestamp getTime2() {
        return time2;
    }

    public void setTime2(java.sql.Timestamp time2) {
        this.time2 = time2;
    }
}
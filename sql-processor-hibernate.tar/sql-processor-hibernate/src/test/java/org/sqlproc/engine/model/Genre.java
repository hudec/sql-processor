package org.sqlproc.engine.model;


public enum Genre {
    ACTION, COMEDY, DRAMA, STORY, SCI_FI;
}
